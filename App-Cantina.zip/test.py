import sqlite3
from sqlite3 import Error
import db

test1 = db
test1.test1()



